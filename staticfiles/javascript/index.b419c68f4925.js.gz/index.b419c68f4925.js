const numberOfPlayers = document.getElementById("numberOfPlayers");

numberOfPlayers.addEventlistner("submit", function(event){
    event.preventDefault();
    console.log(select.value);
})